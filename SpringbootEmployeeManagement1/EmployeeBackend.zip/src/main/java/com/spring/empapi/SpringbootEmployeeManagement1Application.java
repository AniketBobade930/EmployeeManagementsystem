package com.spring.empapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootEmployeeManagement1Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootEmployeeManagement1Application.class, args);
	}

}
