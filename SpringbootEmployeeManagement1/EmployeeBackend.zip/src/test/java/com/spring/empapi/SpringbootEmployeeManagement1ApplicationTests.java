package com.spring.empapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootEmployeeManagement1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
